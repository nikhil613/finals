package com.ust_global;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class Transactionss {
	

	private int TrAccNo2;
	private int TransId;
	private int OpAccNo;
	private double balance;
	private double amount;
	String msg=" ";
	String msg2;
	String option;

	

	private int TrAccNo;
	private double Deposit;
	private double withDraw;
	
	List acNoList = new ArrayList();
	List TransList = new ArrayList();
	List depositList = new ArrayList();
	List withDrawList = new ArrayList();
	List primList=new ArrayList();
	Properties prop;
	Context ctx;
	public Transactionss() throws NamingException {
		prop=new Properties();
		prop.put(Context.PROVIDER_URL, "localhost:1099");
		prop.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		prop.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		ctx=new  InitialContext(prop);	
		msg=" ";
	}

	public int getOpAccNo() {
		return OpAccNo;
	}

	public void setOpAccNo(int opAccNo) {
		OpAccNo = opAccNo;
	}

	public double getDeposit() {
		return Deposit;
	}

	public void setDeposit(double deposit) {
		Deposit = deposit;
	}

	public double getWithDraw() {
		return withDraw;
	}

	public void setWithDraw(double withDraw) {
		this.withDraw = withDraw;
	}

	public List getPrimList() {
		return primList;
	}

	public void setPrimList(List primList) {
		this.primList = primList;
	}

	public int getTransId() {
		return TransId;
	}

	public void setTransId(int transId) {
		TransId = transId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getMsg2() {
		return msg2;
	}

	public void setMsg2(String msg2) {
		this.msg2 = msg2;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}
	public int getTrAccNo() {
		return TrAccNo;
	}

	public void setTrAccNo(int trAccNo) {
		TrAccNo = trAccNo;
	}

	public List getTransList() {
		return TransList;
	}

	public void setTransList(List transList) {
		TransList = transList;
	}
	

	public List getDepositList() {
		return depositList;
	}

	public void setDepositList(List depositList) {
		this.depositList = depositList;
	}

	public List getAcNoList() {
		return acNoList;
	}

	public void setAcNoList(List acNoList) {
		this.acNoList = acNoList;
	}

	public List getWithDrawList() {
		return withDrawList;
	}

	public void setWithDrawList(List withDrawList) {
		this.withDrawList = withDrawList;
	}

	public List getWithdrawList() {
		return withDrawList;
	}

	public void setWithdrawList(List withdrawList) {
		this.withDrawList = withdrawList;
	}

	public int getTrAccNo2() {
		return TrAccNo2;
	}

	public void setTrAccNo2(int trAccNo2) {
		TrAccNo2 = trAccNo2;
	}

	public String depositDetails() throws NamingException, ParseException {
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YYYY HH:mm:ss");
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		TransactionBeanRemote trabr=(TransactionBeanRemote)ctx.lookup("TransactionBean/remote");
		Opening op=new Opening();
		Transaction trans=new Transaction();
		Random random=new Random();
		int xx2=0;
			int x=random.nextInt((999999-115111)+123421)+115111;
		acNoList=balbr.getChequeDetails();
		
		for(int i=0;i<acNoList.size();i++)
		{
			Balance balance=(Balance)acNoList.get(i);
			if(balance.getAccNo()==TrAccNo2)
			{
				TrAccNo=TrAccNo2;
			}
		}
			
			xx2=trabr.getPrimaryValue();
			if(xx2==0)
			{
				xx2=1;
			}
			try{
			OpAccNo=(Integer) sess.getAttribute("accNo2");
			}
			catch(Exception e)
			{
				msg="Login first!!!No backdoor entry allowed";
			}
			
		if(OpAccNo==TrAccNo2)
		{
			msg="YOU CANT TRANSFER TO YOUR OWN ACCOUNT NUMBER";
			return "Deposit";
			
		}
		else if(TrAccNo2==0)
		{
			msg="SPECIFY AN ACCOUNT NUMBER";
			return "Deposit";
		}
		else if(this.amount==0)
		{
			msg="YOU CANT TRANSFER ZERO AMOUNT";
			return "Deposit";
		}
		else if(TrAccNo==TrAccNo2)
		{
			
		Calendar cal = Calendar.getInstance();
		String cals=sdf.format(cal.getTime());
		balbr.withdrawDetails(OpAccNo, this.amount);
		trans.setsId(xx2+1);
		trans.setTransId(x);
		trans.setAccNo(OpAccNo);
		
		trans.setDeposit(0);
		trans.setWithDraw(this.amount);
		trans.setDateTime(cals);
		trabr.addTransactionDetails(trans);
		
		
		balbr.depositDetails(TrAccNo2, this.amount);
		trans.setsId(xx2+2);
		trans.setTransId(x);
		trans.setAccNo(TrAccNo2);
		
		trans.setDeposit(this.amount);
		trans.setWithDraw(0);
		trans.setDateTime(cals);
		trabr.addTransactionDetails(trans);
		msg=this.amount+ " has been transfered to "+TrAccNo2;
		return "Deposit";
		}
		else
		{
			msg="Transaction failed check account number";
			return "Deposit";
		}

		}

	public String TransactionDetails() throws NamingException, ParseException
	{
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		
		msg2="Transaction";
		OpAccNo=(Integer) sess.getAttribute("accNo2");
		TransactionBeanRemote transRemote=(TransactionBeanRemote)ctx.lookup("TransactionBean/remote");
	
		Opening op=new Opening();
		TransList=transRemote.transactionDetails();
		int j=1;
		int flag=0;
		depositList.removeAll(depositList);
		withDrawList.removeAll(withDrawList);
		for(int i=0;i<TransList.size()-1;i++)
		{
		
			Transaction transact=(Transaction)TransList.get(i);
			Transaction transacts=(Transaction)TransList.get(j);
			int trId=transact.getTransId();
			int trId2=transacts.getTransId();
			if(transact.getAccNo()==OpAccNo && transact.getWithDraw()!=0)
			{
				flag=flag+1;
				if(transacts.getDeposit()!=0)
				{
				depositList.add(transacts);
			
				}
			}
			else if(transacts.getAccNo()==OpAccNo && transacts.getDeposit()!=0)
			{
				flag=flag+1;
				if(transact.getWithDraw()!=0)
				{
				withDrawList.add(transact);
				}
			}
		
				j=j+1;

		}

		return msg2;
		
	}
}
	