package com.ust_global;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;





public class Opening 
{
	String userName, userPassword, personName, personAddress;
	String accountNo,option;
	int duration;
	String loanDate, loanDueDate, loanType, roi,branchName,branchCity,branchState;
	double loanAmount=0.0;
	int userID;
	int accNo;
	int accNo2;
	String accType;
	double Balance;
	double Amount;
	String msg;
	int contactNo;
	String Email;
	
	int emiDuration;
	float emiRoi=0f;
	double emiLoanAmount=0.0,emiFinal=0.0;
	
	List<Branch> stateDetails=new ArrayList();
	List<LoanSchan> loanDetails=new ArrayList();
	
	List balList=new ArrayList();
	List balList2=new ArrayList();
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public List getBalList() {
		return balList;
	}
	public void setBalList(List balList) {
		this.balList = balList;
	}
	List<PassWord> aboutMe=new ArrayList<PassWord>();
	
	public List<PassWord> getAboutMe() 
	{
		return aboutMe;
	}
	public void setAboutMe(List<PassWord> aboutMe) 
	{
		this.aboutMe = aboutMe;
	}
	public String getPersonAddress() 
	{
		return personAddress;
	}
	public void setPersonAddress(String personAddress) 
	{
		this.personAddress = personAddress;
	}
	public String getPersonName() 
	{
		return personName;
	}
	public void setPersonName(String personName) 
	{
		this.personName = personName;
	}
	public String getAccountNo() 
	{
		return accountNo;
	}
	public void setAccountNo(String accountNo) 
	{
		this.accountNo = accountNo;
	}
	public String getRoi() {
		return roi;
	}
	public void setRoi(String roi) 
	{
		this.roi = roi;
	}
	public int getDuration() 
	{
		return duration;
	}
	public void setDuration(int duration) 
	{
		this.duration = duration;
	}
	public String getLoanDate() 
	{
		return loanDate;
	}
	public void setLoanDate(String loanDate) 
	{
		this.loanDate = loanDate;
	}
	public String getLoanDueDate() 
	{
		return loanDueDate;
	}
	public void setLoanDueDate(String loanDueDate) 
	{
		this.loanDueDate = loanDueDate;
	}
	public double getLoanAmount() 
	{
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) 
	{
		this.loanAmount = loanAmount;
	}
	public String getLoanType() 
	{
		return loanType;
	}
	public void setLoanType(String loanType) 
	{
		this.loanType = loanType;
	}
	
	
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public List getBalList2() {
		return balList2;
	}
	public void setBalList2(List balList2) {
		this.balList2 = balList2;
	}
	
	public int getAccNo2() {
		return accNo2;
	}
	public void setAccNo2(int accNo2) {
		this.accNo2 = accNo2;
	}
	
	
	Properties prop;
	Context ctx;
	
	
	 
	public int getEmiDuration() {
		return emiDuration;
	}
	public void setEmiDuration(int emiDuration) {
		this.emiDuration = emiDuration;
	}
	public float getEmiRoi() {
		return emiRoi;
	}
	public void setEmiRoi(float emiRoi) {
		this.emiRoi = emiRoi;
	}
	public double getEmiLoanAmount() {
		return emiLoanAmount;
	}
	public void setEmiLoanAmount(double emiLoanAmount) {
		this.emiLoanAmount = emiLoanAmount;
	}
	public double getEmiFinal() {
		return emiFinal;
	}
	public void setEmiFinal(double emiFinal) {
		this.emiFinal = emiFinal;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCity() {
		return branchCity;
	}
	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}
	public String getBranchState() {
		return branchState;
	}
	public void setBranchState(String branchState) {
		this.branchState = branchState;
	}
	public List<Branch> getStateDetails() {
		return stateDetails;
	}
	public void setStateDetails(List<Branch> stateDetails) {
		this.stateDetails = stateDetails;
	}
	public List<LoanSchan> getLoanDetails() {
		return loanDetails;
	}
	public void setLoanDetails(List<LoanSchan> loanDetails) {
		this.loanDetails = loanDetails;
	}
	public Opening() throws NamingException, ParseException 
	{
		prop=new Properties();
		prop.put(Context.PROVIDER_URL, "localhost:1099");
		prop.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		prop.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		ctx=new  InitialContext(prop);	

	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserPassword() 
	{
		return userPassword;
	}
	public void setUserPassword(String userPassword) 
	{
		this.userPassword = userPassword;
	}
	public String newUser()
	{
		String msg="";
		System.out.println("Hello");
		msg="new";
		return msg;
	}
	public String existingUser()
	{
		String msg="";
		System.out.println("Hellosd");
		msg="existing";
		return msg;
	}
	
	public String registration() throws NamingException //This method activates when a new user wants to create an account
	{
		System.out.println("Entering registration method");
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		String user=(String) sess.getAttribute("userName");
		Random random=new Random();
		int f=0;
		int x=random.nextInt((200000-40000)+15500)+40000;
		int xx=random.nextInt((999-100)+1)+100;
		int val=random.nextInt((3-0)+1)+0;
		String acTypeList[]={"SAVINGS","CURRENT","RECURRING DEPOSIT","FIXED DEPOSIT"};
	
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");

		Balance balance=new Balance();
		try
		{
			
			System.out.println("In try");
			PassWord DetailsAdd=new PassWord();
		
			
			DetailsAdd.setUserName(this.userName);
		
			DetailsAdd.setUserPassword(this.userPassword);
			DetailsAdd.setPersonName(this.personName);
			DetailsAdd.setPersonAddress(this.personAddress);
			int length = String.valueOf(accNo).length();
			if(length>=6 && length<=13)
			{
			balance.setUserID(xx);
			balance.setUsername(this.userName);
			balance.setBalance(x);
			balance.setAccType(acTypeList[val]);			
			balance.setAccNo(accNo);
			balance.setContactNo(this.contactNo);
			balance.setEmail(this.Email);
			f=f+1;
			try
			{
			pbr1.addUser(DetailsAdd);
			balbr.addAcNo(balance);
			this.msg="Registration Successful";
			
			return "registrationSuccess";
			}
			catch(Exception e)
			{
				this.msg="Check the values you have entered..Registration failed";
				return "registrationFailed";
			}
			}
			else
			{
				this.msg="Wrong account number...All account number has minimum 6 digits";
				return "registrationFailed";
			}
		}
		catch(Exception e)
		{
			System.out.println("Duplicate ACCOUNT Detected");
			this.msg="Registration has Failed..Duplicate account number or id has been entered";
			return "registrationFailed";
		}
	
	}
	public String login() throws NamingException //This method activates when an existing user wishes to login
, ParseException
	{	
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		List<PassWord> readAllDetails=pbr1.readAll();
		Opening open=new Opening();
		for (int i = 0; i < readAllDetails.size(); i++) 
		{
			PassWord pw=readAllDetails.get(i);
			if(pw.getUserName().equals(this.userName) && pw.getUserPassword().equals(this.userPassword))
			{
				
				FacesContext fc=FacesContext.getCurrentInstance();
				ExternalContext ec=fc.getExternalContext();
				HttpSession session=(HttpSession) ec.getSession(false);
				session.setAttribute("userName", this.userName);
				BalanceBeanRemote balbr = (BalanceBeanRemote) ctx.lookup("BalanceBean/remote");
				balList = balbr.getChequeDetails();
				
				
				for (int i1 = 0; i1 < balList.size(); i1++) {
					Balance bal = (Balance) balList.get(i1);
					if (this.userName.equalsIgnoreCase(bal.getUsername())) {

						this.accNo2 = bal.getAccNo();
						this.userID=bal.getUserID();
						session.setAttribute("accNo2", this.accNo2);
					}
				}
				msg= "Success";
				break;
			}
			else
			{
				msg= "Login Failed";
			}
			
		}
		System.out.println(msg);
		return msg;
	}
	public String logout() //This method activates when the user wishes to logout
	{
		String logoutMsg="";		
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		
		if(sess!=null)
		{
			String x=(String) sess.getAttribute("userName");
			if(x!=null)
			{
				System.out.println("We are going to logout");
				sess.removeAttribute("userName");
				this.userName=null;
				sess.invalidate();
				logoutMsg="LoggedOut";
			}
		}

		return logoutMsg;
	}
	public String loanChecker()
	{
		String msg="d";
		return msg;
	}
	public String loanDatabaseWriter() throws NamingException, ParseException
	{
		LoanSchan loan=new LoanSchan();
		LoanBeanRemote lbr=(LoanBeanRemote)ctx.lookup("LoanBean/remote");
		Calendar calendar=Calendar.getInstance();
		 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	     String stringDate=dateFormat.format(new Date());
	     Date date=dateFormat.parse(stringDate);
	     PassWord pass=new PassWord();
	     Random r=new Random();
	     int b=r.nextInt((5000-11)+1)+11;
	    loan.setLoanID(b);
	    
		loan.setAccountNo(accountNo);
		
		loan.setPersonName(personName);
		loan.setPersonAddress(personAddress);
		if(this.loanType.equalsIgnoreCase("1"))
		{
			loan.setLoanType("Personal Loan");
			loan.setRoi("8.5");
		}
		else if(this.loanType.equalsIgnoreCase("2"))
		{
			loan.setLoanType("Automobile Loan");
			loan.setRoi("12");
		}
		else if(this.loanType.equalsIgnoreCase("3"))
		{
			loan.setLoanType("Education Loan");
			loan.setRoi("20.5");
		}
		loan.setDuration(duration);
		loan.setLoanDate(stringDate);
		calendar.add(Calendar.MONTH, (duration));
		String strDate=dateFormat.format(calendar.getTime());
		System.out.println(strDate);
		loan.setLoanDueDate(strDate);
		loan.setLoanAmount(loanAmount);
		lbr.addLoanDetails(loan);
		
		return "Sanctioned";
		
	}
	public String branchSearch()throws NamingException
	{
		System.out.println("In branchSearch");
		String msg="";
		Branch b=new Branch();
		System.out.println(this.option);
		
			System.out.println(getOption());

			System.out.println(b.getBranchState());
			BranchBeanRemote branchRemote=(BranchBeanRemote)ctx.lookup("BranchBean/remote");
		

			stateDetails=branchRemote.searchByState(this.option);
			System.out.println(stateDetails);
			if(!stateDetails.isEmpty())
			{
				msg="list";
			}
			
		
		System.out.println(msg);
		return msg;
	}
	public String loanTrack() throws NamingException
	{
		System.out.println("In loanSearch");
		String msg="";
		LoanSchan loan=new LoanSchan();
		
			System.out.println(loan.getAccountNo());
			LoanBeanRemote loanRemote=(LoanBeanRemote)ctx.lookup("LoanBean/remote");
		
			this.accountNo=Integer.toString(this.accNo2);
			loanDetails=loanRemote.readAll(this.accountNo);
			System.out.println(loanDetails);
			if(!loanDetails.isEmpty())
			{
				
				msg="LoanOrder";
			}
			else
			{
			msg="failed";
			}
			
		
		System.out.println(msg);
		return msg;
	}
	
	
	public String myInformation() throws NamingException
	{
		System.out.println("I am in myInformation method");
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		BalanceBeanRemote balbr = (BalanceBeanRemote) ctx.lookup("BalanceBean/remote");
		balList = balbr.getChequeDetails();
		for (int i1 = 0; i1 < balList.size(); i1++) {
			Balance bal = (Balance) balList.get(i1);
			if (this.userName.equalsIgnoreCase(bal.getUsername())) {

				this.contactNo=bal.getContactNo();
				this.Email=bal.getEmail();
			}
		}
		 aboutMe=pbr1.displayUserByName(this.userName);
		 pbr1.displayUserByName(this.userName);

		   if(!aboutMe.isEmpty())
			
		    msg="AboutMe";
		   else
		    msg="fail";
		   return msg;
	}
	public String showBalance() throws NamingException
	{
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		String user=(String) sess.getAttribute("userName");
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		balList2=balbr.getChequeDetails();
		balList.removeAll(balList);
		try
		{
		for(int i=0;i<balList2.size();i++)
		{
			Balance bal=(Balance)balList2.get(i);
			if(user.equalsIgnoreCase(bal.getUsername()))
			{
				balList.add(bal);
				
			}
		}
		
		return "balance";
		}
		catch(Exception e)
		{
			return "bfailed";
		}
}
	public String emiCalculator() throws NamingException
	{
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		
		if(this.loanType.equalsIgnoreCase("1"))
		{
			String roi="8.5";
			sess.setAttribute("roi", this.roi);
			this.emiFinal=this.emiLoanAmount*(1+Math.pow(8.5/100, this.emiDuration/12))/(this.emiDuration/12*12);
		}
		else if(this.loanType.equalsIgnoreCase("2"))
		{
			String roi="12";
			sess.setAttribute("roi", this.roi);
			this.emiFinal=this.emiLoanAmount*(1+Math.pow(12/100, this.emiDuration/12))/(this.emiDuration/12*12);
		}
		else if(this.loanType.equalsIgnoreCase("3"))
		{
			String roi="20.5";
			sess.setAttribute("roi", this.roi);
			this.emiFinal=this.emiLoanAmount*(1+Math.pow(20.5/100, this.emiDuration/12))/(this.emiDuration/12*12);
		}
		
		return "Okay";
	}
	
}
