package com.ust_global;

import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BalanceClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		List balList=balbr.getChequeDetails();
		Random random=new Random();
		int x=random.nextInt((3-0)+1)+0;
		for(int i=0;i<balList.size();i++)
			{
				Balance bal=(Balance)balList.get(i);
				
				System.out.println(bal.accNo+"....."+bal.accType+"....."+bal.Balance+"......"+bal.username);
				System.out.println(bal.Amount+" was added to this account in the last transaction");
			}
		System.out.println(x);
		
	
	}
	
}
