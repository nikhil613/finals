package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class BalanceBean
 */
@Stateful
public class BalanceBean implements BalanceBeanRemote {
	@PersistenceContext(name = "BalanceUnit")
	EntityManager entityManager;

	/**
	 * Default constructor.
	 */
	public BalanceBean() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List getChequeDetails() {
		// TODO Auto-generated method stub
		List BalDetails = entityManager.createQuery("FROM BALINQ").getResultList();
		return BalDetails;
	}

	public boolean addAcNo(Balance balance) {
		boolean msg = false;

		try {
			entityManager.merge(balance);
			msg = true;

		} catch (Exception e) {
			msg = false;
		}
		return msg;

	}
	@Override
	public void addTransactionDetails(Balance b) {
		entityManager.persist(b);
		
	}
	
	public boolean depositDetails(int accno, double amt) {
		List allDeposit=entityManager.createQuery("FROM BALINQ").getResultList();
		boolean msg=false;
		for(int i=0;i<allDeposit.size();i++)
		{
			Balance balance=(Balance)allDeposit.get(i);
			int value=balance.getAccNo();
		
			System.out.println(value);
			if(accno==value)
			{
				balance.setAmount(amt);
				double finalBalance=balance.getBalance()+amt;
				balance.setBalance(finalBalance);
				msg=true;
			}
			else
			{
				msg=false;
			}
		}
		return msg;
		
	}
	
	@Override
	public boolean withdrawDetails(int accno, double amt) {
		List allDeposit=entityManager.createQuery("FROM BALINQ").getResultList();
		boolean msg=false;
		for(int i=0;i<allDeposit.size();i++)
		{
			Balance balance=(Balance)allDeposit.get(i);
			int value=balance.getAccNo();
			System.out.println(value);
			if(accno==value)
			{
				if(balance.getBalance()<amt)
				{
					msg=false;
				}else{
					balance.setAmount(amt);
					double finalBalance=balance.getBalance()-amt;
					balance.setBalance(finalBalance);
					msg=true;
				}
			}
			
		}
	return msg;
	}


}
