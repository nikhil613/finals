package com.ust_global;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class DirTransfer {
	int accNo;
	double Amount;
	String msg;
	
	public DirTransfer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String directTransfering() throws NamingException, IOException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		ChequeBeanRemote chqbr=(ChequeBeanRemote)ctx.lookup("ChequeBean/remote");
		FileWriter fw=new FileWriter("Fg.txt");

		BufferedWriter bw=new BufferedWriter(fw);
		
		boolean value=chqbr.addDetails(this.accNo, this.Amount);
		if(value==true)
		{
			
		msg="Amount has been transfered";
		double amt=this.Amount;
		String x=Double.toString(this.Amount);
		bw.write(x);
	
		bw.write((int) amt);
		return "success";
		}
		else
		{
			msg="Check your account number transaction failed";
			return "failure";
		}
		
		
	
		
	}

	
}
