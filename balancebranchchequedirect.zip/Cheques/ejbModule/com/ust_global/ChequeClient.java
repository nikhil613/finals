package com.ust_global;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ChequeClient {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws NamingException, IOException {
		// TODO Auto-generated method stub
		BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YYYY");
		Random random=new Random();
		int accNo1=Integer.parseInt(buffer.readLine());
		double Amount=Double.parseDouble(buffer.readLine());
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		ChequeBeanRemote chqbr=(ChequeBeanRemote)ctx.lookup("ChequeBean/remote");
		
		List chklist=chqbr.getChequeDetails();
	
	
		
		boolean msg=chqbr.addDetails(accNo1, Amount);
		System.out.println(msg);
//		for(int i=0;i<chklist.size();i++)
//		{
//			Cheque chq=(Cheque)chklist.get(i);
//			
//			System.out.println(chq.getAccNo()+"........"+chq.getAmount());
//		}
	}

}
