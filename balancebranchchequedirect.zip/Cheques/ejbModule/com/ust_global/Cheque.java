package com.ust_global;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="BALINQ")
public class Cheque implements Serializable{
int userID;
int accNo;
double Balance;
double Amount;


public Cheque() {
	super();
	// TODO Auto-generated constructor stub
}

@Id
@Column(name="USERID")

public int getUserID() {
	return userID;
}

public void setUserID(int userID) {
	this.userID = userID;
}
public int getAccNo() {
	return accNo;
}

public void setAccNo(int accNo) {
	this.accNo = accNo;
}

public double getBalance() {
	return Balance;
}

public void setBalance(double balance) {
	Balance = balance;
}
public double getAmount() {
	return Amount;
}

public void setAmount(double amount) {
	Amount = amount;
}



}
