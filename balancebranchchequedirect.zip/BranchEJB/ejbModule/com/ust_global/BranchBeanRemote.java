package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface BranchBeanRemote 
{
	public List<Branch> searchByState(String branchState);
	
}
