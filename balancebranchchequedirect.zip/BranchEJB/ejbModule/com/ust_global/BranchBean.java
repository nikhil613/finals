package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class BranchBean
 */
@Stateless
public class BranchBean implements BranchBeanRemote {

    /**
     * Default constructor. 
     */
    public BranchBean() {
        // TODO Auto-generated constructor stub
    }
    @PersistenceContext(name="branchUnit")
    private EntityManager entityManager;

	@Override
	public List<Branch> searchByState(String branchState) 
	{
		System.out.println("hey");
		List<Branch> stateSearch=entityManager.createQuery("From branchdetails").getResultList();
		List<Branch> searchResult = new ArrayList();
		if(stateSearch!=null)
		{
		for(Branch branch:stateSearch) 
		{
			if(branch.getBranchState().equalsIgnoreCase(branchState))
			{
				searchResult.add(branch);
			}
		}
		}
		return searchResult;
	}

}
