package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BranchClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException 
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);

		BranchBeanRemote br=(BranchBeanRemote)ctx.lookup("BranchBean/remote");
		String branchName="Aberdeen";
		String branchState="Andaman and Nicobar";
		List<Branch> brnch=br.searchByState(branchState);
		System.out.println(brnch);
		if(brnch!=null)
		{
			for(int i=0;i<brnch.size();i++)
			{
				System.out.println(brnch.get(i).getBranchId()+" " +brnch.get(i).getBranchCity());
				
			}
		}
		else
			System.out.println("result is null");
	}

}

